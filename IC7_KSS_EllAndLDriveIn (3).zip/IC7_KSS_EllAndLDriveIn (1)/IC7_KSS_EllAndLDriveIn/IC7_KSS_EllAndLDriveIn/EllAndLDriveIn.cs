﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC7_KSS_EllAndLDriveIn
{
    public partial class EllAndLDriveIn : Form
    {
        //global level for constants
        const decimal FRIED_FISH_PRICE_MINI = 6.95m;
        const decimal FRIED_FISH_PRICE_REG = 8.95m;
        const decimal FRIED_SHRIMP_PRICE_MINI = 6.95m;
        const decimal FRIED_SHRIMP_PRICE_REG = 8.95m;
        const decimal TERIYAKI_STEAK_PRICE_MINI = 5.95m;
        const decimal TERIYAKI_STEAK_PRICE_REG = 7.25m;
        const decimal HAMBURGER_STEAK_PRICE_MINI = 5.95m;
        const decimal HAMBURGER_STEAK_PRICE_REG = 7.25m;
        const decimal LOCO_MOCO_PRICE_MINI = 5.95m;
        const decimal LOCO_MOCO_PRICE_REG = 7.25m;
        const decimal BBQ_SHORT_RIBS_PRICE_MINI = 5.95m;
        const decimal BBQ_SHORT_RIBS_PRICE_REG = 7.25m;

        const decimal TAX = 0.04712m;
        public EllAndLDriveIn()
        {
            InitializeComponent();
        }

        private void EllAndLDriveIn_Load(object sender, EventArgs e)
        {
            friedFishMiniTextBox.Text = "0";
            friedFishRegTextBox.Text = "0";
            friedShrimpMiniTextBox.Text = "0";
            friedShrimpRegTextBox.Text = "0";
            teriyakiSteakMiniTextBox.Text = "0";
            teriyakiSteakRegTextBox.Text = "0";
            hamburgerSteakMiniTextBox.Text = "0";
            hamburgerSteakRegTextBox.Text = "0";
            locoMocoMiniTextBox.Text = "0";
            locoMocoRegTextBox.Text = "0";
            bBQShortRibsMiniTextBox.Text = "0";
            bBQShortRibsRegTextBox.Text = "0";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            friedFishMiniTextBox.Text = "0";
            friedFishRegTextBox.Text = "0";
            friedShrimpMiniTextBox.Text = "0";
            friedShrimpRegTextBox.Text = "0";
            teriyakiSteakMiniTextBox.Text = "0";
            teriyakiSteakRegTextBox.Text = "0";
            hamburgerSteakMiniTextBox.Text = "0";
            hamburgerSteakRegTextBox.Text = "0";
            locoMocoMiniTextBox.Text = "0";
            locoMocoRegTextBox.Text = "0";
            bBQShortRibsMiniTextBox.Text = "0";
            bBQShortRibsRegTextBox.Text = "0";
            subtotalLabel.Text = "";
            taxLabel.Text = "";
            totalLabel.Text = "";
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //prep
            int miniFriedFishQuant;
            int regFriedFishQuant;
            int miniFriedShrimpQuant;
            int regFriedShrimpQuant;
            int miniTeriyakiSteakQuant;
            int regTeriyakiSteakQuant;
            int miniHamburgerSteakQuant;
            int regHamburgerSteakQuant;
            int miniLocoMocoQuant;
            int regLocoMocoQuant;
            int miniBBQShortRibsQuant;
            int regBBQShortRibsQuant;

            decimal subtotal;
            decimal tax;
            decimal total;

            if (!int.TryParse(friedFishMiniTextBox.Text, out miniFriedFishQuant) || miniFriedFishQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                friedFishMiniTextBox.Focus();
                friedFishMiniTextBox.SelectAll();
                return;
            }
            if (!int.TryParse(friedFishRegTextBox.Text, out regFriedFishQuant) || regFriedFishQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                friedFishRegTextBox.Focus();
                friedFishRegTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(friedShrimpMiniTextBox.Text, out miniFriedShrimpQuant) || miniFriedShrimpQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                friedShrimpMiniTextBox.Focus();
                friedShrimpMiniTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(friedShrimpRegTextBox.Text, out regFriedShrimpQuant) || regFriedShrimpQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                friedShrimpRegTextBox.Focus();
                friedShrimpRegTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(teriyakiSteakMiniTextBox.Text, out miniTeriyakiSteakQuant) || miniTeriyakiSteakQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                teriyakiSteakMiniTextBox.Focus();
                teriyakiSteakMiniTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(teriyakiSteakRegTextBox.Text, out regTeriyakiSteakQuant) || regTeriyakiSteakQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                teriyakiSteakRegTextBox.Focus();
                teriyakiSteakRegTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(hamburgerSteakMiniTextBox.Text, out miniHamburgerSteakQuant) || miniHamburgerSteakQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                hamburgerSteakMiniTextBox.Focus();
                hamburgerSteakMiniTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(hamburgerSteakRegTextBox.Text, out regHamburgerSteakQuant) || regHamburgerSteakQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                hamburgerSteakRegTextBox.Focus();
                hamburgerSteakRegTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(locoMocoMiniTextBox.Text, out miniLocoMocoQuant) || miniLocoMocoQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                locoMocoMiniTextBox.Focus();
                locoMocoMiniTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(locoMocoRegTextBox.Text, out regLocoMocoQuant) || regLocoMocoQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                locoMocoRegTextBox.Focus();
                locoMocoRegTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(bBQShortRibsMiniTextBox.Text, out miniBBQShortRibsQuant) || miniBBQShortRibsQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bBQShortRibsMiniTextBox.Focus();
                bBQShortRibsMiniTextBox.SelectAll();
                return;
            } 
            if (!int.TryParse(bBQShortRibsRegTextBox.Text, out regBBQShortRibsQuant) || regBBQShortRibsQuant < 0)
            {
                MessageBox.Show("please enter quantity >= 0", "Error: Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                bBQShortRibsRegTextBox.Focus();
                bBQShortRibsRegTextBox.SelectAll();
                return;
            } 

            //calc
        
            subtotal = miniFriedFishQuant * FRIED_FISH_PRICE_MINI + regFriedFishQuant * FRIED_FISH_PRICE_REG + miniFriedShrimpQuant * FRIED_SHRIMP_PRICE_MINI + regFriedShrimpQuant * FRIED_SHRIMP_PRICE_REG + miniTeriyakiSteakQuant * TERIYAKI_STEAK_PRICE_MINI + regTeriyakiSteakQuant * TERIYAKI_STEAK_PRICE_REG + miniHamburgerSteakQuant * HAMBURGER_STEAK_PRICE_MINI + regHamburgerSteakQuant * HAMBURGER_STEAK_PRICE_REG + miniLocoMocoQuant * LOCO_MOCO_PRICE_MINI + regLocoMocoQuant * LOCO_MOCO_PRICE_REG + miniBBQShortRibsQuant * BBQ_SHORT_RIBS_PRICE_MINI + regBBQShortRibsQuant * BBQ_SHORT_RIBS_PRICE_REG;
            
            //tax
            tax = TAX * subtotal;
            
            total = tax + subtotal;
            taxLabel.Text = tax.ToString("C");
            totalLabel.Text = total.ToString("C");
            subtotalLabel.Text = subtotal.ToString("C");
            //fin
            friedFishMiniTextBox.Focus();
            friedFishMiniTextBox.SelectAll();

        }
    }
}
